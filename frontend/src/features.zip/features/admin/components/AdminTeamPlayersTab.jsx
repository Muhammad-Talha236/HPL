import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  Users,
  Search,
  UserPlus,
  Pencil,
  Trash2,
  RefreshCw,
  Loader2,
  Save,
  X,
} from "lucide-react";

import AddTeamPlayerModal from "./AddTeamPlayerModal";

import {
  teamPlayersAdminApi,
  getTeamPlayerError,
} from "../services/teamPlayersAdminApi";

const PAGE_SIZE = 10;

const formatDate = (value) => {
  if (!value) return "—";

  const date = new Date(value);

  return Number.isNaN(date.getTime())
    ? "—"
    : date.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
};

function PlayerAvatar({ name }) {
  const initials = String(name || "?")
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();

  return (
    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-xs font-bold text-[#078052]">
      {initials}
    </div>
  );
}

export default function AdminTeamPlayersTab({ teamId }) {
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const [search, setSearch] = useState("");
  const [position, setPosition] = useState("ALL");
  const [page, setPage] = useState(1);

  const [addOpen, setAddOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [jersey, setJersey] = useState("");
  const [busyId, setBusyId] = useState(null);

  const loadPlayers = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const data = await teamPlayersAdminApi.getSquad(teamId);
      setPlayers(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(getTeamPlayerError(err));
    } finally {
      setLoading(false);
    }
  }, [teamId]);

  useEffect(() => {
    loadPlayers();
  }, [loadPlayers]);

  const positions = useMemo(() => {
    return [
      ...new Set(
        players.map((row) => row.player?.position).filter(Boolean)
      ),
    ].sort();
  }, [players]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();

    return players.filter((membership) => {
      const player = membership.player || {};

      const matchesSearch =
        !q ||
        String(player.name || "").toLowerCase().includes(q) ||
        String(player.registration_number || "")
          .toLowerCase()
          .includes(q);

      const matchesPosition =
        position === "ALL" || player.position === position;

      return matchesSearch && matchesPosition;
    });
  }, [players, search, position]);

  const totalPages = Math.max(
    1,
    Math.ceil(filtered.length / PAGE_SIZE)
  );

  const currentPage = Math.min(page, totalPages);

  const visible = filtered.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE
  );

  const beginEdit = (membership) => {
    setEditingId(membership.team_player_id);
    setJersey(
      membership.jersey_number === null ||
        membership.jersey_number === undefined
        ? ""
        : String(membership.jersey_number)
    );
    setNotice("");
    setError("");
  };

  const saveJersey = async (membershipId) => {
    if (
      jersey &&
      (!Number.isInteger(Number(jersey)) ||
        Number(jersey) < 1 ||
        Number(jersey) > 99)
    ) {
      setError("Jersey number must be between 1 and 99.");
      return;
    }

    setBusyId(membershipId);
    setError("");

    try {
      await teamPlayersAdminApi.updateJersey(
        membershipId,
        jersey
      );

      setEditingId(null);
      setNotice("Jersey number updated successfully.");
      await loadPlayers();
    } catch (err) {
      setError(getTeamPlayerError(err));
    } finally {
      setBusyId(null);
    }
  };

  const removePlayer = async (membership) => {
    const confirmed = window.confirm(
      `Remove ${membership.player?.name || "this player"} from the team?\n\nThis will deactivate the team membership, not delete the player account.`
    );

    if (!confirmed) return;

    setBusyId(membership.team_player_id);
    setError("");
    setNotice("");

    try {
      await teamPlayersAdminApi.removePlayer(
        membership.team_player_id
      );

      setNotice("Player removed from the active squad.");
      await loadPlayers();
    } catch (err) {
      setError(getTeamPlayerError(err));
    } finally {
      setBusyId(null);
    }
  };

  return (
    <section className="min-w-0 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 p-5">
        <div className="flex items-center gap-3">
          <div className="rounded-lg bg-emerald-50 p-2.5 text-[#078052]">
            <Users size={20} />
          </div>

          <div>
            <h2 className="text-lg font-semibold text-[#10213f]">
              Team Players
            </h2>

            <p className="mt-0.5 text-xs text-slate-500">
              {players.length} active squad members
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          <button
            type="button"
            onClick={loadPlayers}
            disabled={loading}
            aria-label="Refresh players"
            className="rounded-lg border border-slate-200 p-2.5 text-slate-600 hover:bg-slate-50 disabled:opacity-50"
          >
            <RefreshCw size={17} />
          </button>

          <button
            type="button"
            onClick={() => setAddOpen(true)}
            className="inline-flex items-center gap-2 rounded-lg bg-[#078052] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#066a44]"
          >
            <UserPlus size={16} />
            Add Player
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 border-b border-slate-100 p-4">
        <div className="relative min-w-[180px] flex-1">
          <Search
            size={17}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          />

          <input
            type="search"
            value={search}
            onChange={(event) => {
              setSearch(event.target.value);
              setPage(1);
            }}
            placeholder="Search by player name or registration number..."
            className="w-full rounded-lg border border-slate-200 py-2.5 pl-10 pr-3 text-sm outline-none focus:border-[#078052]"
          />
        </div>

        <select
          value={position}
          onChange={(event) => {
            setPosition(event.target.value);
            setPage(1);
          }}
          className="rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700"
        >
          <option value="ALL">All Positions</option>

          {positions.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>
      </div>

      {error && (
        <div
          role="alert"
          className="mx-4 mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700"
        >
          {error}
        </div>
      )}

      {notice && (
        <div
          role="status"
          className="mx-4 mt-4 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700"
        >
          {notice}
        </div>
      )}

      {/* Table */}
      <div className="w-full overflow-x-auto">
        <table className="w-full min-w-[690px] border-collapse text-left">
          <thead className="bg-[#f5f8fc]">
            <tr className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              <th className="px-4 py-3">#</th>
              <th className="px-4 py-3">Player</th>
              <th className="px-4 py-3">Position</th>
              <th className="px-4 py-3">Jersey</th>
              <th className="px-4 py-3">Joined On</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {loading ? (
              <tr>
                <td colSpan={7} className="py-12 text-center">
                  <Loader2
                    size={22}
                    className="mx-auto animate-spin text-[#078052]"
                  />
                  <p className="mt-2 text-sm text-slate-500">
                    Loading players...
                  </p>
                </td>
              </tr>
            ) : visible.length === 0 ? (
              <tr>
                <td
                  colSpan={7}
                  className="px-4 py-12 text-center text-sm text-slate-500"
                >
                  {players.length === 0
                    ? "No active players in this team."
                    : "No players match your filters."}
                </td>
              </tr>
            ) : (
              visible.map((membership, index) => {
                const player = membership.player || {};
                const isEditing =
                  editingId === membership.team_player_id;
                const isBusy =
                  busyId === membership.team_player_id;

                return (
                  <tr
                    key={membership.team_player_id}
                    className="hover:bg-slate-50/70"
                  >
                    <td className="px-4 py-3 text-sm text-slate-500">
                      {(currentPage - 1) * PAGE_SIZE + index + 1}
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <PlayerAvatar name={player.name} />

                        <div className="min-w-0">
                          <Link
                            to={`/players/${player.player_id}`}
                            className="block text-sm font-semibold text-[#10213f] hover:text-[#078052]"
                          >
                            {player.name || "Unknown player"}
                          </Link>

                          <p className="text-xs text-slate-500">
                            {player.registration_number || "—"}
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3 text-sm text-slate-700">
                      {player.position || "—"}
                    </td>

                    <td className="px-4 py-3">
                      {isEditing ? (
                        <input
                          type="number"
                          min="1"
                          max="99"
                          step="1"
                          value={jersey}
                          onChange={(event) =>
                            setJersey(event.target.value)
                          }
                          className="w-16 rounded-md border border-slate-300 px-2 py-1.5 text-sm"
                        />
                      ) : (
                        <span className="text-sm font-semibold text-[#10213f]">
                          {membership.jersey_number ?? "—"}
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-3 text-sm text-slate-600">
                      {formatDate(membership.joined_at)}
                    </td>

                    <td className="px-4 py-3">
                      <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700">
                        Active
                      </span>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        {isEditing ? (
                          <>
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() =>
                                saveJersey(membership.team_player_id)
                              }
                              title="Save jersey"
                              aria-label="Save jersey"
                              className="rounded-md p-2 text-[#078052] hover:bg-emerald-50"
                            >
                              <Save size={17} />
                            </button>

                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => setEditingId(null)}
                              title="Cancel editing"
                              aria-label="Cancel editing"
                              className="rounded-md p-2 text-slate-500 hover:bg-slate-100"
                            >
                              <X size={17} />
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => beginEdit(membership)}
                              title="Edit jersey number"
                              aria-label="Edit jersey number"
                              className="rounded-md p-2 text-blue-600 hover:bg-blue-50"
                            >
                              <Pencil size={17} />
                            </button>

                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => removePlayer(membership)}
                              title="Remove from team"
                              aria-label="Remove from team"
                              className="rounded-md p-2 text-red-600 hover:bg-red-50"
                            >
                              {isBusy ? (
                                <Loader2
                                  size={17}
                                  className="animate-spin"
                                />
                              ) : (
                                <Trash2 size={17} />
                              )}
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 px-5 py-4">
        <p className="text-xs text-slate-500">
          {filtered.length === 0
            ? "Showing 0 players"
            : `Showing ${(currentPage - 1) * PAGE_SIZE + 1}–${Math.min(
                currentPage * PAGE_SIZE,
                filtered.length
              )} of ${filtered.length} players`}
        </p>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={currentPage <= 1}
            onClick={() => setPage(currentPage - 1)}
            className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium disabled:opacity-40"
          >
            Previous
          </button>

          <span className="text-xs text-slate-600">
            {currentPage} / {totalPages}
          </span>

          <button
            type="button"
            disabled={currentPage >= totalPages}
            onClick={() => setPage(currentPage + 1)}
            className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium disabled:opacity-40"
          >
            Next
          </button>
        </div>
      </div>

      <AddTeamPlayerModal
        open={addOpen}
        teamId={teamId}
        onClose={() => setAddOpen(false)}
        onSuccess={() => {
          setNotice("Player added to the team successfully.");
          loadPlayers();
        }}
      />
    </section>
  );
}